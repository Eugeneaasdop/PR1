﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GeografWPF.Classes;

namespace GeografWPF.Resusrs
{
    /// <summary>
    /// Логика взаимодействия для PageCountry.xaml
    /// </summary>
    public partial class PageCountry : Page
    {
        public PageCountry()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Class.ClassFrame.frmObj.Navigate(new Addcon((Country)DtgSQL.SelectedItem));
        }

        private void BTNadd_Click(object sender, RoutedEventArgs e)
        {
            Class.ClassFrame.frmObj.Navigate(new Addcon(null));
        }

        private void BTNdel_Click(object sender, RoutedEventArgs e)
        {
            var personsForRemoving = DtgSQL.SelectedItems.Cast<Country>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {personsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GeografyEntities1.GetContext().Country.RemoveRange(personsForRemoving);
                    GeografyEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GeografyEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
            }
        }
    }
}
